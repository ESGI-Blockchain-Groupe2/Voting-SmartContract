// Uncomment when deploy : const HDWalletProvider = require('truffle-hdwallet-provider-privkey');
// !!! Only put testing-purpose private keys !!!
const privateKey = "";
const endpointUrl = "";

module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",
      port: 7545,
      network_id: "5777",
    },
    kovan: {
      provider: function() {
        return new HDWalletProvider(
            //private keys array
            [privateKey],
            //url to ethereum node
            endpointUrl
        )
      },
      gas: 5000000,
      gasPrice: 25000000000,
      network_id: 42
    }
  },
  // Configure your compilers
  compilers: {
    solc: {
      version: "0.7.0",    // Fetch exact version from solc-bin (default: truffle's version)
    }
  }
};